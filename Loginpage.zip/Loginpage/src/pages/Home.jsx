import { Link } from "react-router-dom";
import "../index.css"; // Ensure this imports your styles

const Home = () => (
  <div className="home-container">
    <div className="overlay">
      <h1>Welcome to Soni Rameshbhai & Son</h1>
      <p>Please <strong>Login</strong> or <strong>Register</strong> to continue.</p>

      <div className="nav-links1">
        <div><Link to="/login">Login</Link></div><br></br>
        <div><Link to="/register">Register</Link></div>
      </div>
    </div>
  </div>
);

export default Home;
