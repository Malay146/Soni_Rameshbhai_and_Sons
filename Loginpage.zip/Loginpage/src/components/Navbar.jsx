import { Link } from "react-router-dom";
import logo from '../assets/logo.png';

const Navbar = () => (

  <nav className="navbar">
    <div className="logo-container">
      <Link to="/">
        <img src={logo} alt="Logo" className="logo" />
        
      </Link>
    </div>
    <div className="nav-links">
           <Link to="/">Home</Link>
        </div>
    
  </nav>
);

export default Navbar;
