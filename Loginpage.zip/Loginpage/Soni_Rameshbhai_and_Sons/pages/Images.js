import React from "react";

const Images = () => {
  return (
     <section className="hero">
      <h1>Gallery</h1>
      <p>[Images of products will be shown here]</p>
     </section>
  );
};

export default Images;