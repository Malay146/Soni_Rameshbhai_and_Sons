import React from "react";

const ContactUs = () => {
  return (
     <section className="hero">
      <h1>Contact Us</h1>
      <p>Visit us at: Main Market, Surat, Gujarat<br />Phone: +91 98765 43210</p>
     </section>
  );
};

export default ContactUs;